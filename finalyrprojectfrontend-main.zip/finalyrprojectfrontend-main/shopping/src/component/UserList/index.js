import React from 'react'
import Tabel from '../Tabel.js'
//import Tabel from './src/component/Tabel';
/**
* @author
* @function UserList
**/

const UserList = (props) => {
  return(
    <div id="userlist" >
    <Tabel/>

    </div>
   )

 }

export default UserList;